/* 	Nik
	Daniel Lodge 500 727 539

/*
We evaluate the node's entire left subtree and count each node we cover storing that into LVal, we evaluate the node's right subtree and count each node we cover storing that into RVal. If LVal-RVal is less than 2 and RVal-LVal is less than 2, then we move to the next node and repeat this process (evaluate the new node's L and R subtrees). This will be done until the subtraction condition fails, or until we reach the base case (an empty tree). 
*/

avl(void, Y).
avl(tree(Root,Left,Right), Val) :- 	
	avl(Left, LVal), avl(Right, RVal), LVal - RVal < 2, RVal-Lval < 2, avl(Left,X), avl(Right,Y).



